create function st_tpi(rast raster, nband integer DEFAULT 1, pixeltype text DEFAULT '32BF'::text, interpolate_nodata boolean DEFAULT false)
  returns raster
immutable
parallel safe
language sql
as $$
SELECT public.ST_tpi($1, $2, NULL::raster, $3, $4)
$$;

alter function st_tpi(raster, integer, text, boolean)
  owner to postgres;

