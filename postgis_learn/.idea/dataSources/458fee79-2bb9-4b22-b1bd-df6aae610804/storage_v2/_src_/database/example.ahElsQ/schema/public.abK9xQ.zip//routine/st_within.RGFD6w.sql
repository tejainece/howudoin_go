create function st_within(geom1 geometry, geom2 geometry)
  returns boolean
immutable
parallel safe
language sql
as $$
SELECT $2 OPERATOR(public.~) $1 AND public._ST_Contains($2,$1)
$$;

comment on function st_within(geometry, geometry)
is 'args: A, B - Returns true if the geometry A is completely inside geometry B';

alter function st_within(geometry, geometry)
  owner to postgres;

