create function st_aspng(rast raster, nbands integer[], compression integer)
  returns bytea
immutable
strict
parallel safe
language plpgsql
as $$
DECLARE
		compression2 int;
		options text[];
	BEGIN
		IF compression IS NOT NULL THEN
			IF compression > 9 THEN
				compression2 := 9;
			ELSEIF compression < 1 THEN
				compression2 := 1;
			ELSE
				compression2 := compression;
			END IF;

			options := array_append(options, 'ZLEVEL=' || compression2);
		END IF;

		RETURN public.st_aspng(st_band($1, $2), options);
	END;

$$;

comment on function st_aspng(raster, integer [], integer)
is 'args: rast, nbands, compression - Return the raster tile selected bands as a single portable network graphics (PNG) image (byte array). If 1, 3, or 4 bands in raster and no bands are specified, then all bands are used. If more 2 or more than 4 bands and no bands specified, then only band 1 is used. Bands are mapped to RGB or RGBA space.';

alter function st_aspng(raster, integer [], integer)
  owner to postgres;

