create function st_snaptogrid(rast raster, gridx double precision, gridy double precision, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125, scalex double precision DEFAULT 0, scaley double precision DEFAULT 0)
  returns raster
immutable
strict
parallel safe
language sql
as $$
SELECT public._ST_GdalWarp($1, $4, $5, NULL, $6, $7, $2, $3)
$$;

comment on function st_snaptogrid(raster, double precision, double precision, text, double precision, double precision,
                                  double precision)
is 'args: rast, gridx, gridy, algorithm=NearestNeighbour, maxerr=0.125, scalex=DEFAULT 0, scaley=DEFAULT 0 - Resample a raster by snapping it to a grid. New pixel values are computed using the NearestNeighbor (english or american spelling), Bilinear, Cubic, CubicSpline or Lanczos resampling algorithm. Default is NearestNeighbor.';

alter function st_snaptogrid(raster, double precision, double precision, text, double precision, double precision, double precision)
  owner to postgres;

