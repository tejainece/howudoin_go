create function st_isvalid(geometry, integer)
  returns boolean
immutable
strict
parallel safe
language sql
as $$
SELECT (public.ST_isValidDetail($1, $2)).valid
$$;

comment on function st_isvalid(geometry, integer)
is 'args: g, flags - Returns true if the ST_Geometry is well formed.';

alter function st_isvalid(geometry, integer)
  owner to postgres;

